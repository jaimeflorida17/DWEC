import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EXButtonComponent } from './exbutton.component';

describe('ExbuttonComponent', () => {
  let component: EXButtonComponent;
  let fixture: ComponentFixture<EXButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EXButtonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EXButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
