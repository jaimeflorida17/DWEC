import { Component } from '@angular/core';

@Component({
  selector: 'app-exsecond-view',
  templateUrl: './exsecond-view.component.html',
  styleUrls: ['./exsecond-view.component.css']
})
export class EXSecondViewComponent {

}
